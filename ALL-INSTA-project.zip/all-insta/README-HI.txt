ALL INSTA - शुरुआती प्रोजेक्ट

क्या है:
- मोबाइल और कंप्यूटर पर चलने वाला installable PWA starter.
- Home feed, sample stories, create post (इस डिवाइस पर), like, search, profile और demo messages/reels screens.

चलाने का तरीका:
1. इस ZIP को extract करें.
2. index.html को ब्राउज़र में खोलकर डिजाइन देख सकते हैं.
3. PWA install करने के लिए इसे HTTPS hosting पर upload करना होगा; फिर Chrome में Add to Home screen चुनें.

Android APK:
यह ZIP APK फाइल नहीं है; यह APK बनाने का source project है.
APK बनाने के लिए Android Studio, Android SDK और Java/Gradle वाला कंप्यूटर चाहिए:
1. Node.js और Android Studio install करें.
2. इस folder में terminal खोलें और `npm install` चलाएँ.
3. `npx cap add android` चलाएँ.
4. `npx cap sync android` चलाएँ.
5. `npx cap open android` चलाएँ, Android Studio में Build > Build Bundle(s) / APK(s) > Build APK(s).

जरूरी सीमा:
यह अभी demo है। Login/signup, वास्तविक कई users के बीच posts, cloud photo/video storage, followers, chat, notifications और moderation के लिए Firebase/Supabase जैसे backend, database, authentication, storage और security rules जोड़ने होंगे। Demo posts browser के local storage में रहती हैं; दूसरे लोगों को नहीं दिखतीं। किसी भी real user का password खुद store न करें।
